package cl.desafiolatam;

import java.util.Scanner;

public class Resistencia {

	public static void main(String[] args) {
		/*Se solicita al usuario ingresar por consola las tres resistencias
		 * del requeriiento. Cada una de las resistencias son de tipo float,
		 * ya que pueden tener decimales. 
		 */
		Scanner sc = new Scanner(System.in);
		System.out.printf("Resistencia 1: ");
		float resistencia1 = sc.nextFloat();
		System.out.printf("Resistencia 2: ");
		float resistencia2 = sc.nextFloat();
		System.out.printf("Resistencia 3: ");
		float resistencia3 = sc.nextFloat();
		
		float resistenciaTotal = 1/((1/resistencia1) +1/resistencia2 + 1/resistencia3);
		
		System.out.printf("La resistencia total es de %f", resistenciaTotal);
	}

}
