package latam;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

public class MiArchivo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		crearArchivo("directorio","fichero.txt");
		buscarTexto("fichero.txt","prueba");
	}

	public static void crearArchivo(String nombreDirectorio,String fichero) {
		ArrayList<String> lista = new ArrayList<String>();
		lista.add("Perro");
		lista.add("Gato");
		lista.add("Juan");
		lista.add("Daniel");
		lista.add("Juan");
		lista.add("Gato");
		lista.add("Perro");
		lista.add("Camila");
		lista.add("Daniel");
		lista.add("Camila");

		File directorio = new File("src/"+nombreDirectorio);
		File archivo = new File("src/"+nombreDirectorio+"/"+fichero); 
		if (!directorio.exists()) {
			if (directorio.mkdirs()) {
				System.out.println("Directorio creado");
				try { 
						archivo.createNewFile();
						BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(archivo));
						for (Iterator iterator = lista.iterator(); iterator.hasNext();) {
							String string = (String) iterator.next();
							bufferedWriter.write(string + "\n");

						}
						bufferedWriter.close(); 
				} catch (IOException e) {
					e.printStackTrace();
				}
			} else {
				System.out.println("Error al crear directorio");
			}
		} else {
			System.out.println("Directorio ya esta creado");

		}
	}

	public static void buscarTexto(String fichero, String texto) {
		String nombreArchivo = "src/carpeta/"+fichero;
		FileReader fr = null;
		BufferedReader br = null;
		String data = "";
		ArrayList<String> buscar = new ArrayList<String>();
		try {
			File archivo = new File("src/carpeta/"+fichero); 
			if(archivo.exists()) {
				fr = new FileReader(nombreArchivo);
				
				br = new BufferedReader(fr);
				data = br.readLine();
				while (data != null) {
					System.out.println(data);
					if (data.equals(texto)) {
						System.out.println(" encontrado ");
						buscar.add(data);
					}

					data = br.readLine();
				}
				br.close();
				fr.close();
				System.out.println(" cantidad de repeticiones del texto -> " + buscar.size());
			}
			else {
				System.out.println("El fichero ingresado no existe");
			}
			
		} catch (Exception e) {
			System.out.println("Excepcion leyendo fichero " + nombreArchivo + ": " + e);
		}

		
	}

}