package main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import modelo.ArchivoServicio;
import modelo.Producto;
import modelo.ProductoServicio;
import utilidades.Utilidad;

public class Menu {
	ProductoServicio productoServicio = new ProductoServicio();
	ArchivoServicio archivoServicio = new ArchivoServicio();
	String fileName = "productos";
	String fileName1 = "ProductosImportados.csv";
	Scanner scanner = new Scanner(System.in);

		public void iniciarMenu() {
			List<String> opcionesMenu = new ArrayList<String>();
			opcionesMenu.add("Listar Producto");
			opcionesMenu.add("Editar Datos");
			opcionesMenu.add("Importar Datos");
			opcionesMenu.add("Salir");
			Menu menu = new Menu();
			menu.seleccionOpcion(opcionesMenu);
		}

		protected int construirMenu(List<String> pOpcionesMenu) {
			List<String> opcionesMenu = pOpcionesMenu;
			int largo = opcionesMenu.size();
			for (int i = 0; i < largo; i++) {
				System.out.println(i + 1 + " " + opcionesMenu.get(i));
			}
			int opcion = 0;
			System.out.println("Ingrese una opción:");
			try {
				opcion = scanner.nextInt();
			} catch (Exception error) {
				scanner.nextLine();
			}
			if (opcion < 1 || opcion >= largo + 1) {
				System.out.println("Selección no permitida");
			}
			return opcion;
		}

		public void seleccionOpcion(List<String> pOpcionesMenu) {
			boolean continuar = false;
			int resultado;

			do {
				resultado = construirMenu(pOpcionesMenu);
				switch (resultado) {
				case 1:
					listarProductos();
					break;
				case 2:
					editarProducto();
					break;
			    case 3:
			    	cargarDatos();
			    	break;
				case 4:
					salirSistema();
				default:
					System.out.println("Opción no válida");
				}
			} while (!continuar);
		}

		private void listarProductos() {
			productoServicio.listarProductos();
			Utilidad.stopAndContinue();
		}
		private void editarProducto() {
			System.out.println("Editar Producto");
			System.out.println("Ingrese el número 1 para editar los datos ingresados del Producto");
			int opcionEdicion = scanner.nextInt();
			scanner.nextLine();
			System.out.println("Ingrese código del producto:");
			String run1 = scanner.nextLine();
			List<Producto> listaProductos = productoServicio.getListaProductoss();
				
			for (Producto producto : listaProductos) {
				if (producto.getCodigo().equals(run1)){
					if (opcionEdicion == 1) {
						actualizarDatosProducto(producto);
					} 
				}
			}
		}
		private void actualizarDatosProducto(Producto producto) {
			System.out.println("1.-El nombre del articulo actual es: " + producto.getArticulo());
			System.out.println("2.-El código del producto: " + producto.getCodigo());
			System.out.println("3.-El color del producto: " + producto.getColor());
			System.out.println("4.-La descripción del producto: " + producto.getDescripcion());
			System.out.println("5.-La marca del producto: " + producto.getMarca());
			System.out.println("6.-El precio del producto: " + producto.getPrecio());
			System.out.println("7.-La talla del producto: " + producto.getTalla());
			
			System.out.println("Ingrese la opción a editar de los datos del producto:");
			int opcionCliente = scanner.nextInt();
			scanner.nextLine();
			switch (opcionCliente) {
			case 1:
				System.out.println("Ingrese nuevo nombre del articulo:");
				String nombreProducto = scanner.nextLine();
				producto.setArticulo(nombreProducto);
				break;
			case 2:
				System.out.println("Ingrese nuevo código del articulo:");
				String codigoProducto = scanner.nextLine();
				producto.setCodigo(codigoProducto);
				break;
			case 3:
				System.out.println("Ingrese nuevo color del producto:");
				String colorProducto = scanner.nextLine();
				producto.setColor(colorProducto);
				break;
			case 4:
				System.out.println("Ingrese la nueva descripción del producto:");
				String descripcionProducto = scanner.nextLine();
				producto.setDescripcion(descripcionProducto);
				break;
			case 5:
				System.out.println("Ingrese la nueva marca del producto:");
				String marcaProducto = scanner.nextLine();
				producto.setMarca(marcaProducto);
				break;
			case 6:
				System.out.println("Ingrese el nuevo precio del producto:");
				String precioProducto = scanner.nextLine();
				producto.setPrecio(precioProducto);
				break;
			case 7:
				System.out.println("Ingrese la nueva talla del producto:");
				String tallaProducto = scanner.nextLine();
				producto.setTalla(tallaProducto);
				break;
			default:
				System.out.println("Usted marco una opción incorrecta");
			}
			Utilidad.stopAndContinue();
		}

		private void cargarDatos() {
			System.out.println("Cargar Datos");
			System.out.println("Ingresa la ruta en donde se encuentra el archivo ProductosImportados.csv:");

			List<Producto> listaProductos = archivoServicio.cargarDatos(fileName1);
			if (listaProductos != null && !listaProductos.isEmpty()) {
				productoServicio.setListaProductos(listaProductos);				
			    System.out.println("Datos cargados correctamente en la lista");
				Utilidad.stopAndContinue();
			} else {
				System.out.println("No se pudo cargar los datos del archivo " + fileName1);
			}
		}

		private void salirSistema() {
			System.out.println("Abandonando el sistema de clientes...");
			Utilidad.timeToWait();
			System.out.println("Acaba de salir del sistema");
			Utilidad.stopAndContinue();
			System.exit(0);
		}
	}


