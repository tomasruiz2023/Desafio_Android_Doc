package modelo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class ArchivoServicio {
	Scanner scanner = new Scanner(System.in);

	@SuppressWarnings("static-access")
	public List<Producto> cargarDatos(String fileName) {
		List<Producto> listaProductos = new ArrayList<Producto>();
		String filePath = scanner.nextLine();
		String file = filePath + File.separator + fileName;

		FileReader fr = null;
		BufferedReader br = null;

		try {
			fr = new FileReader(new File(file));
			br = new BufferedReader(fr);
			List<Producto> l = br.lines().map(line -> line.split(","))
					.map(values -> new Producto(values[0], values[1], values[2], values[3], values[4], values[5], values[6]))
					.collect(Collectors.toList());
			System.out.println(l.toString());
			return l;
		} catch (Exception error) {
			System.out.println("No se pudo cargar el archivo .csv");
		} finally {
			try {
				if (null != fr) {
					fr.close();
				}
			} catch (Exception error) {
				System.out.println("No se pudo crear el archivo");
			}
		}
		return null;
	}

}
