package model;

public enum CategoriaEnum {
	ACTIVO, INACTIVO
}
