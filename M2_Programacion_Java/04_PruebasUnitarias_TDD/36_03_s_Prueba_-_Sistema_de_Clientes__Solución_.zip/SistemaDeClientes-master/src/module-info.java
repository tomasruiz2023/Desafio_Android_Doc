module PruebaIntento1 {
	requires junit;
}