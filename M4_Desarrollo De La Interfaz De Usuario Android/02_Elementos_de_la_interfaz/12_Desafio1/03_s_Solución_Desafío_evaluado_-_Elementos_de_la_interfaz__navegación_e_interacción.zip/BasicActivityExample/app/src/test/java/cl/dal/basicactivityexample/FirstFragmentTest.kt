package cl.dal.basicactivityexample

import junit.framework.Assert.assertEquals
import org.junit.Test

internal class FirstFragmentTest {

    @Test
    fun `validate length`() {
        val pass = ""

        val result = validateLength(pass)

        assertEquals(result, false)
    }

    @Test
    fun `validate upper with one upper`() {
        val pass = "A"

        val result = hasUpper(pass)

        assertEquals(result, true)
    }

    @Test
    fun `validate upper with upper`() {
        val pass = "Aasasd"

        val result = hasUpper(pass)

        assertEquals(result, true)
    }

    @Test
    fun `validate upper with lower`() {
        val pass = "asdasdasd"

        val result = hasUpper(pass)

        assertEquals(result, false)
    }
}
