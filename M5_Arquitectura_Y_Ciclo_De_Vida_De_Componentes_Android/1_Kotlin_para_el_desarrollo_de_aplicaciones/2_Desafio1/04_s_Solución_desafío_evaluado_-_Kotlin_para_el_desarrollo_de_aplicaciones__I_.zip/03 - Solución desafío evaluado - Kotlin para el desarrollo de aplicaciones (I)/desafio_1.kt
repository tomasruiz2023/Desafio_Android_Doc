package com.desafiolatam

/** Completa o modifica la clase Author, permitiendo almacenar
 *  Nombres
 *  Apellidos
 *  Obras destacadas
 *  Año de nacimiento
 *  Año de muerte (en caso de estar vivo, debe soportar valor nulo)
 *  Comentario
 */
data class Author(
    val name: String,
    val yearOfBirth: String,
    val yearOfDeath: String,
    val outstandingWork: String,
    val comment: String,
)

/**
 * Calcula la edad basándose solamente en los año
 * Ejemplo: si nació en 1950 y estamos en 2022, entonces la edad es 72 años
 */
fun calculateAge(yearOfBirth: Int, yearOfDeath: Int): Int = yearOfDeath - yearOfBirth

/**
 * No es necesario leer parámetros de entrada
 * la función "println" imprime en pantalla
 */
fun main() {

    val author = Author(
        name = "Howard Phillips Lovecraft",
        outstandingWork = "The Call Of Cthulhu",
        comment = "",
        yearOfBirth = "1917",
        yearOfDeath = "1937"
    )

    val ageOfDeath = calculateAge(
        yearOfBirth = author.yearOfBirth.toInt(),
        yearOfDeath = author.yearOfDeath.toInt()
    )

    /*
        Ejemplo:
        ++++++++++++++++++++++++++++++++++++++++++++++++++++
        + Nombre del autor: Howard Phillips Lovecraft      +
        + Obras destacadas: The Call of Cthulhu            +
        + Año de nacimiento: 1917                          +
        + Año de muerte: 1937, murió a los 20 años de edad +
        ++++++++++++++++++++++++++++++++++++++++++++++++++++
    */
    
    println(
        "++++++++++++++++++++++++++++++++++++++++++++++++++++\n" +
                "+ Nombre del autor: ${author.name}      +\n" +
                "+ Obras destacadas: ${author.outstandingWork}            +\n" +
                "+ Año de nacimiento: ${author.yearOfBirth}                          +\n" +
                "+ Año de muerte: ${author.yearOfDeath} murió a los $ageOfDeath años de edad  +\n" +
                "++++++++++++++++++++++++++++++++++++++++++++++++++++\n"
    )
}