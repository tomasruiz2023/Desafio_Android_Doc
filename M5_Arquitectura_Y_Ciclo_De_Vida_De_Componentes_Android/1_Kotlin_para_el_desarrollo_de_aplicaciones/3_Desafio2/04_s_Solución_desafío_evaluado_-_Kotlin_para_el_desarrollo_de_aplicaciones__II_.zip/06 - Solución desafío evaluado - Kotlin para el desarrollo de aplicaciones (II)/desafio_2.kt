package com.desafiolatam

data class Product(
    val id: Int,
    var name: String,
    val description: String?,
    var isAvailable: Boolean = true,
    var isEnable: Boolean = true,
    var stock: Int = 0,
)

/**
- Cambiar todos los nombres de producto a mayúscula (2 Puntos)
- Cuando la descripción sea nula, entonces reemplazar con "N/A" (1 Puntos)
- Cuando un valor sea true, entonces mostrar "SI" (2 Puntos)
- Cuando un valor sea false, entonces mostrar con "NO" (1 Puntos)
- Cuando el stock sea cero (0), entonces mostrar "Sin Stock" (1 Puntos)
- Ordena los resultados por stock descendiente (2 Puntos)
- Entregar un archivo .kt con el nombre del desafío más el nombre y apellido del alumno, ejemplo: desafio2_NombreApellido.kt (1 Puntos
 */

fun main() {

    populateData().values.sortedByDescending { it?.stock }
        .forEach {
            println("+++++++++++++++++++++++++++++++++++++++++++++")
            val product = it
            println(
                "ID:            ${product?.id} \n" +
                "NOMBRE:        ${product?.name?.uppercase()} \n" +
                "DESCRIPCIÓN:   ${product?.description.showNA()} \n" +
                "DISPONIBLE:    ${product?.isAvailable?.showYesOrNo()} \n" +
                "HABILITADO     ${product?.isEnable?.showYesOrNo()} \n" +
                "STOCK:         ${product?.stock?.checkStock()}"
            )
            println("+++++++++++++++++++++++++++++++++++++++++++++")
        }
}

/**
 * Puedes crear extensiones para resolver 2,3,4 y 5
 */

// ejemplo:
fun String?.showNA(): String = if(this == null) "N/A" else this

fun Boolean.showYesOrNo(): String = if (this) "SI" else "NO"

fun Int.checkStock(): String = if (this > 0) this.toString() else "Sin Stock"

/**
 * ADVERTENCIA: No modificar la funcion populateData() o los datos
 */
fun populateData(): MutableMap<Int, Product?> =
    mutableMapOf(
        1 to Product(
            id = 100,
            name = "Lapiz",
            description = null,
            isAvailable = true,
            isEnable = true,
            stock = 20
        ),
        2 to Product(
            id = 101,
            name = "Hoja de oficio",
            description = "Hojas para impresora",
            isAvailable = false,
            isEnable = true,
            stock = 150
        ),
        3 to Product(
            id = 102,
            name = "Hoja de carta",
            description = "Hojas para impresora",
            isAvailable = true,
            isEnable = true,
            stock = 100
        ),
        4 to Product(
            id = 103,
            name = "Corchetera",
            description = null,
            isAvailable = true,
            isEnable = false,
            stock = 150
        ),
        5 to Product(
            id = 104,
            name = "Tijeras",
            description = null,
            isAvailable = true,
            isEnable = true,
            stock = 100
        ),
        6 to Product(
            id = 105,
            name = "Sillas de oficina",
            description = null,
            isAvailable = false,
            isEnable = true,
            stock = 0
        ),
    )
