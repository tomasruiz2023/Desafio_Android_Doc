package com.desafiolatam.desafio6m5.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.desafiolatam.desafio6m5.R
import com.desafiolatam.desafio6m5.databinding.ItemStoreBinding




import com.desafiolatam.desafio6m5.model.Store

class StoreAdapter (
    private val storeList: List<Store>) : RecyclerView.Adapter<StoreAdapter.StoreViewHolder>() {

        lateinit var binding: ItemStoreBinding

        var onClick: ((Int) -> Unit)? = null

        inner class StoreViewHolder(private val binding: ItemStoreBinding) : RecyclerView.ViewHolder(binding.root){
            fun onBind(store: Store){
                with(binding) {
                    tvStoreName.text = store.name
                    tvStoreAttention.text= store.openingHours
                    Glide.with(ivStore.context)
                        .load(store.photo)
                        .centerCrop()
                       .error(R.drawable.baseline_error_24)
                        .into(binding.ivStore)
                }

                binding.clStore.setOnClickListener {
                    onClick?.invoke(store.id)
                }
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StoreViewHolder {
            binding = ItemStoreBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return StoreViewHolder(binding)
        }

        override fun getItemCount(): Int {
            return storeList.size
        }

        override fun onBindViewHolder(holder: StoreViewHolder, position: Int) {
            holder.onBind(storeList[position])
        }
}
