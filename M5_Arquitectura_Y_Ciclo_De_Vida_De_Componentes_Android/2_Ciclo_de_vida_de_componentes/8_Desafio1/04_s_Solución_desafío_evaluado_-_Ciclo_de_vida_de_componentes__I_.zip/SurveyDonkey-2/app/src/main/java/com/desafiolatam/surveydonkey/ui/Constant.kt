package com.desafiolatam.surveydonkey.ui

const val TAG = "surveydonkey :::::: "

const val COLOR = "Color: "
const val COLORS = "Colores: "
const val MATERIAL = "Material: "
const val MATERIALS = "Materiales: "
