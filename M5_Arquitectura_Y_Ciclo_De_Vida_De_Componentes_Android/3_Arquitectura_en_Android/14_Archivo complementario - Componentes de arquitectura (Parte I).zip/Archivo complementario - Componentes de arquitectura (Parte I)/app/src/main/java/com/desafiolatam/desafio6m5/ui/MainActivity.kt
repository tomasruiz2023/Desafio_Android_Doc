package com.desafiolatam.desafio6m5.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.desafiolatam.desafio6m5.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Para obtener el listado de tiendas debes ocupar la clase StoreRepository
        // la funcion getStoreList retorna un listado de sucursales
        // Por ejmeplo:

        /* val storeList = StoreRepository().getStoreList()
        storeList.forEach { store ->
            // Listado de tiendas
            Log.d("MainActivity", "onCreate: store = $store")

            // Utiliza Glide para mostrar las imagenes en el recyclerview y en la vista de detalles
            // Ejemplo:
            Glide.with(this)
                .load(store.photo)
                .centerCrop()
                .into(binding.ivExample)
        } */
    }
}


