package com.desafiolatam.viewmodel

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class MainViewModel : ViewModel() {

    private val _counterLowerMutableStateFlow: MutableStateFlow<Int> = MutableStateFlow(10)
    val counterLowerStateFlow: StateFlow<Int> = _counterLowerMutableStateFlow.asStateFlow()

    fun decreaseLower() {
        _counterLowerMutableStateFlow.value -= 1
        _counterUpperMutableStateFlow.value += 1
    }

    private val _counterUpperMutableStateFlow: MutableStateFlow<Int> = MutableStateFlow(10)
    val counterUpperStateFlow: StateFlow<Int> = _counterUpperMutableStateFlow.asStateFlow()

    fun decreaseUpper() {
        _counterUpperMutableStateFlow.value -= 1
        _counterLowerMutableStateFlow.value += 1
    }
}