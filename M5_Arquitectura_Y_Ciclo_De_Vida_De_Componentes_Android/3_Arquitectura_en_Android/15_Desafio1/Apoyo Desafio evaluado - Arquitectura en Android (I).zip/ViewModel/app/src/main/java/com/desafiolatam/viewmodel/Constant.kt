package com.desafiolatam.viewmodel

const val TAG = "MainViewModel >>>>>>>>>>>>>>>"