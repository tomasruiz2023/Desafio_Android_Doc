package com.desafiolatam.helloworldservice

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import com.desafiolatam.helloworldservice.service.HelloService

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btnStart = this.findViewById(R.id.btn_start) as AppCompatButton

        btnStart.setOnClickListener {
            Intent(this, HelloService::class.java).also {
                startService(it)
            }
        }
    }
}