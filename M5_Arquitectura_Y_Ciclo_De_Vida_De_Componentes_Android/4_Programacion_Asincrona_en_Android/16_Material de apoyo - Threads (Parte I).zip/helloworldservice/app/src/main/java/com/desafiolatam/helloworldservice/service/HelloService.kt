package com.desafiolatam.helloworldservice.service

import android.app.Service
import android.content.Intent
import android.os.*
import android.widget.Toast

class HelloService : Service() {

    private var serviceLooper: Looper? = null
    private var serviceHandler: ServiceTask? = null

    override fun onCreate() {
        HandlerThread("HelloService", Process.THREAD_PRIORITY_BACKGROUND).apply {
            start()
            serviceLooper = looper
            serviceHandler = ServiceTask(looper)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Toast.makeText(this, "Service starting!", Toast.LENGTH_LONG).show()
        serviceHandler?.obtainMessage()?.also { message: Message ->
            message.arg1 = startId
            serviceHandler?.sendMessage(message)
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        Toast.makeText(this, "Service done!", Toast.LENGTH_LONG).show()
    }

    private inner class ServiceTask(looper: Looper) : Handler(looper) {
        override fun handleMessage(msg: Message) {
            try {
                Thread.sleep(5000L)
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
            }
        }
    }
}
