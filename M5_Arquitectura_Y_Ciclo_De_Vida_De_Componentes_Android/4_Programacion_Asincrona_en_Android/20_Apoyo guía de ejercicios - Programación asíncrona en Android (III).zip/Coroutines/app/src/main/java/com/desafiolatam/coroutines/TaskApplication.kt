package com.desafiolatam.coroutines

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * NO MODIFICAR
 */

@HiltAndroidApp
class TaskApplication : Application()