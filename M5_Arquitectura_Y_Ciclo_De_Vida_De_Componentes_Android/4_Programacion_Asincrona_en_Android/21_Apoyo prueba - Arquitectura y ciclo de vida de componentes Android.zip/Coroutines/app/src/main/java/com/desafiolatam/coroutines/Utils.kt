package com.desafiolatam.coroutines

/*
INSERT INTO task VALUES
(1,"Pagar la cuenta de la luz", "Pagar antes de que se cumpla la fecha de vencimiento", 1),
(2,"Cortar el pasto", "Comprar maquina para cortar el pasto", 0),
(3,"Ir al gimnasio","", 0),
(4,"Comprar cosas para el asado","Invitar a la familia", 0),
(5,"Lavar ropa","Lavar ropa el fin de semana", 1),
(6,"Llamar a mi mamá","No olvidar llamarla para su cumpleaños", 1),
(7,"Nota","Revisar aire en los neumaticos antes del viaje", 1),
(8,"Comprar","Comprar comida para los perros", 0)
*/
