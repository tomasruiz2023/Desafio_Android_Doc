# Este proyecto es la solución del Desafío 1 - Acceso a datos en Android

### Explicacion:

- Transformar objetos JSON a data class:
    - Para hacer esto, vemos cuales son los datos que se necesitanb mostrar y creamos una data
      class, esta clase sera nuestra DTO

- Leer datos desde Room y mostrarlos en pantalla:
  - La funcion `getWeatherData()`, llama `getWeatherData()` en la interfaz DAO y luego usando la
    funcion `entityListToDtoList()` definida en el mapper, toma los datos desde la base de datos
    los cuales son entity y los transforma a DTO:

```
    override suspend fun getWeatherData(): Flow<List<WeatherDto>?> =
        weatherDao.getWeatherData().map { entity ->
            entity?.let {
                entityListToDtoList(it)
            }
        }
```
  - Luego en el viewModel, ya que no es necesario hacer ningun tipo de transformacion,
    usamos `repository.getWeatherData().stateIn(viewModelScope)`
  - Finalmente los podemos mostrar en el `MainFragment`, a traves del adapter

- Editar nombre de ciudad y mostrarlo actualizado por pantalla haciendo uso de StateFlow:
  - Ya que no se espesifica que metodo ocupar, usaremos un FragmentDialog, este dialog llama a la funcion `saveCityName(cityName: String)`:
```
    suspend fun saveCityName(cityName: String) {
        viewModelScope.launch(dispatcherIo) {
            repository.clearAll()
            repository.insertData(initialData(cityName = cityName))
        }
    }
```  
  - Notese que estamos limpiando la db cada vez que insertamos un nombre de ciudad `repository.clearAll()`
     