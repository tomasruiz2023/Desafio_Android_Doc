package com.desafiolatam.weatherlatam.view.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.desafiolatam.weatherlatam.data.WeatherRepositoryImp
import com.desafiolatam.weatherlatam.model.WeatherDto
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class WeatherViewModel(private val repository: WeatherRepositoryImp) : ViewModel() {

    private val dispatcherIo: CoroutineDispatcher = Dispatchers.IO

    suspend fun insertData() {
        viewModelScope.launch(dispatcherIo) {
            repository.getWeatherData().collectLatest {
                it?.let { list ->
                    if (list.isEmpty()) repository.insertData(initialData())
                }
            }
        }
    }

    suspend fun getWeather() = repository.getWeatherData().stateIn(viewModelScope)

    suspend fun getWeatherDataById(id: Int) =
        repository.getWeatherDataById(id).stateIn(viewModelScope)

    suspend fun saveCityName(cityName: String) {
        viewModelScope.launch(dispatcherIo) {
            repository.clearAll()
            repository.insertData(initialData(cityName = cityName))
        }
    }

    private fun initialData(cityName: String? = null): WeatherDto = WeatherDto(
        id = 0,
        currentTemp = 24.0,
        maxTemp = 32.3,
        minTemp = -2.3,
        pressure = 101.2,
        humidity = 34.4,
        windSpeed = 20.4,
        sunrise = 168565865,
        sunset = 1685704250,
        cityName = cityName ?: "Santiago, Chile"
    )
}

