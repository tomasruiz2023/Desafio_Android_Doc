## Este proyecto es el archivo de ayuda del Desafío 1 - Acceso a datos en Android

**TIPS:**
- No desperdicies tiempo en el diseño, enfócate en que el código funcione.
- Ten cuidado con los datos y las coroutines.
- Recuerda usar `suspend` cuando guardes, actualices o borres datos.
- No uses `suspend` fun con queries tipo `SELECT`.
- El proyecto ya contiene una data class DTO que te puede ayudar a completar el desafío
- La conexión a la base de datos ya existe
- El llamado a la clase repository desde el viewModel ya existe
- Para editar el nombre de la ciudad NO se especifica cómo se debe hacer, por lo que puedes utilizar el método que te acomode mas