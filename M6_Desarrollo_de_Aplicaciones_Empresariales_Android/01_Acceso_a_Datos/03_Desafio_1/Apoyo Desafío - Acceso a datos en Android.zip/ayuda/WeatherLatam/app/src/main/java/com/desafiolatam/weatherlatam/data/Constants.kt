package com.desafiolatam.weatherlatam.data

const val ITEM_ID = "ITEM_ID"
const val CELSIUS = "CELSIUS"
const val FAHRENHEIT = "FAHRENHEIT"