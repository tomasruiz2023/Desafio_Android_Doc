## Este proyecto es la solución del Desafío 1 - Consumo de API

- Para transformar los datos desde la API a un clase DTO, usa un mapper.
- Usar correctamente RepositoryImp y ViewMode significa, por ejemplo, no hacer cálculos o transformaciones de datos en los fragments.
- Apoyate en las guías de ejercicios.
